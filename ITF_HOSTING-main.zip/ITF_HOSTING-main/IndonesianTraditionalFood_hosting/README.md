# IndonesianTraditionalFood

## Project SetUp

👉 Download the zip file

👉 Extract the file and copy **IndonesianTraditionalFood** folder

    Paste inside root directory
        * For xampp xampp/htdocs 
        * For wamp wamp/www
        * For lamp var/www/html

👉 Open PHPMyAdmin (http://localhost/phpmyadmin)

    Create a database with name FOOD
    Import food.sql file(given inside the zip package in SQL file folder)
   
👉 Run the script 

    For User Panel: http://localhost/IndonesianTraditionalFood/
    
    For admin panel: http://localhost/IndonesianTraditionalFood/admin/
    
 ## Credential for Admin panel :

> username: **admin**       
> password: **admin**
