<div class="footer container-fluid bg-dark text-light">
    <p class="text-center py-2 mb-0"> ©Copyright IndonesianTraditionalFood 2023 </p>
</div>